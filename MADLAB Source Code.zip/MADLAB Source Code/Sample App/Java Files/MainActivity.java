package com.example.newapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText username , password;
    Button registerBtn , loginSwitch;
    DBHelper db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        registerBtn = findViewById(R.id.register);
        loginSwitch = findViewById(R.id.login_nav);

        db= new DBHelper(this);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Username or Password cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean checkUser = db.checkUsername(user);
                if(checkUser){
                    Toast.makeText(MainActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean insert = db.insertData(user , pass);
                if(!insert){
                    Toast.makeText(MainActivity.this , "Error in Registering" , Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(MainActivity.this , "Registration Successful" , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext() , Dashboard.class);
                intent.putExtra("username", user);
                startActivity(intent);
            }
        });

        loginSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext() , LoginActivity.class);
                startActivity(intent);
            }
        });

    }
}