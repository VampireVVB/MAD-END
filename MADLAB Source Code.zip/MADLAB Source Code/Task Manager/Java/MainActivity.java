package com.example.lab8q1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText etTaskName, etDueDate;
    Spinner spinnerPriority;
    Button btnAdd;
    ListView listView;
    ArrayList<String> taskList;
    ArrayAdapter<String> adapter;
    ArrayList<Integer> taskIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        etTaskName = findViewById(R.id.et_task_name);
        etDueDate = findViewById(R.id.et_due_date);
        spinnerPriority = findViewById(R.id.spinner_priority);
        btnAdd = findViewById(R.id.btn_add);
        listView = findViewById(R.id.listView);

        // Spinner setup
        String[] priorityLevels = {"High", "Medium", "Low"};
        ArrayAdapter<String> priorityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, priorityLevels);
        spinnerPriority.setAdapter(priorityAdapter);

        taskList = new ArrayList<>();
        taskIds = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        listView.setAdapter(adapter);

        loadTasks();

        btnAdd.setOnClickListener(v -> {
            String taskName = etTaskName.getText().toString();
            String dueDate = etDueDate.getText().toString();
            String priority = spinnerPriority.getSelectedItem().toString();

            if (!taskName.isEmpty() && !dueDate.isEmpty()) {
                databaseHelper.addTask(taskName, dueDate, priority);
                loadTasks();
                etTaskName.setText("");
                etDueDate.setText("");
                Toast.makeText(this, "Task Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            int taskId = taskIds.get(position);
            showTaskOptions(taskId);
        });
    }

    private void loadTasks() {
        taskList.clear();
        taskIds.clear();
        Cursor cursor = databaseHelper.getAllTasks();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                String dueDate = cursor.getString(2);
                String priority = cursor.getString(3);

                taskList.add(name + " - " + dueDate + " - " + priority);
                taskIds.add(id);
            } while (cursor.moveToNext());
        }
        adapter.notifyDataSetChanged();
    }

    private void showTaskOptions(int taskId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit or Delete Task")
                .setItems(new String[]{"Edit", "Delete"}, (dialog, which) -> {
                    if (which == 0) {
                        // Edit task
                        Toast.makeText(this, "Edit feature can be implemented here", Toast.LENGTH_SHORT).show();
                    } else {
                        // Delete task
                        databaseHelper.deleteTask(taskId);
                        loadTasks();
                        Toast.makeText(this, "Task Deleted", Toast.LENGTH_SHORT).show();
                    }
                });
        builder.show();
    }
}