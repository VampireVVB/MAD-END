package com.example.everythingapp;

import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

public class PastBookingsFragment extends Fragment {
    private ListView listViewBookings;
    private DatabaseHelper databaseHelper;
    private String username;
    private BookingAdapter adapter;

    // Local array for seat types
    private final String[] seatTypes = {"Economy", "Business", "First Class"};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_past_bookings, container, false);

        username = ((MainActivity) requireActivity()).getUsername();
        databaseHelper = new DatabaseHelper(requireContext());
        listViewBookings = view.findViewById(R.id.listViewBookings);

        loadBookings();

        listViewBookings.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = (Cursor) adapter.getItem(position);
                showBookingOptions(cursor.getInt(cursor.getColumnIndex("id")));
            }
        });

        return view;
    }

    private void showBookingOptions(final int bookingId) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Booking Options")
                .setItems(new String[]{"Update", "Delete"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            showUpdateDialog(bookingId);
                        } else {
                            deleteBooking(bookingId);
                        }
                    }
                })
                .show();
    }

    private void showUpdateDialog(final int bookingId) {
        Cursor cursor = databaseHelper.getBookingById(bookingId);
        if (cursor.moveToFirst()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
            View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_update_booking, null);

            EditText etName = dialogView.findViewById(R.id.etName);
            EditText etAge = dialogView.findViewById(R.id.etAge);
            EditText etDate = dialogView.findViewById(R.id.etDate);
            EditText etTime = dialogView.findViewById(R.id.etTime);
            Spinner spinnerSeat = dialogView.findViewById(R.id.spinnerSeat);

            // Pre-fill existing values
            etName.setText(cursor.getString(cursor.getColumnIndex("name")));
            etAge.setText(String.valueOf(cursor.getInt(cursor.getColumnIndex("age"))));
            etDate.setText(cursor.getString(cursor.getColumnIndex("date")));
            etTime.setText(cursor.getString(cursor.getColumnIndex("time")));

            // Use local array for spinner
            ArrayAdapter<String> seatAdapter = new ArrayAdapter<>(
                    requireContext(),
                    android.R.layout.simple_spinner_item,
                    seatTypes
            );
            seatAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerSeat.setAdapter(seatAdapter);

            // Set spinner selection based on the value from the database
            String seatTypeFromDb = cursor.getString(cursor.getColumnIndex("seat_type"));
            for (int i = 0; i < seatTypes.length; i++) {
                if (seatTypes[i].equals(seatTypeFromDb)) {
                    spinnerSeat.setSelection(i);
                    break;
                }
            }

            builder.setView(dialogView)
                    .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            boolean success = databaseHelper.updateBooking(
                                    bookingId,
                                    etName.getText().toString(),
                                    Integer.parseInt(etAge.getText().toString()),
                                    etDate.getText().toString(),
                                    etTime.getText().toString(),
                                    spinnerSeat.getSelectedItem().toString()
                            );

                            if (success) {
                                Toast.makeText(requireContext(), "Booking updated!", Toast.LENGTH_SHORT).show();
                                loadBookings();
                            }
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
        cursor.close();
    }

    private void deleteBooking(int bookingId) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete this booking?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (databaseHelper.deleteBooking(bookingId)) {
                            Toast.makeText(requireContext(), "Booking deleted", Toast.LENGTH_SHORT).show();
                            loadBookings();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadBookings() {
        Cursor cursor = databaseHelper.getBookings(username);
        adapter = new BookingAdapter(requireContext(), cursor);
        listViewBookings.setAdapter(adapter);
    }
}
