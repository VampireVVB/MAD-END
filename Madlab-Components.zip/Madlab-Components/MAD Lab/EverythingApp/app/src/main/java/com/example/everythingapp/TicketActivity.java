package com.example.everythingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TicketActivity extends AppCompatActivity {
    private TextView textViewTicketName, textViewTicketAge, textViewTicketDate, textViewTicketTime,
            textViewTicketSeatType, textViewTicketMeal, textViewTicketInsurance;
    private Button buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);

        textViewTicketName = findViewById(R.id.textViewTicketName);
        textViewTicketAge = findViewById(R.id.textViewTicketAge);
        textViewTicketDate = findViewById(R.id.textViewTicketDate);
        textViewTicketTime = findViewById(R.id.textViewTicketTime);
        textViewTicketSeatType = findViewById(R.id.textViewTicketSeatType);
        textViewTicketMeal = findViewById(R.id.textViewTicketMeal);
        textViewTicketInsurance = findViewById(R.id.textViewTicketInsurance);
        buttonBack = findViewById(R.id.buttonBack);

        // Get data from intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String name = extras.getString("name");
            int age = extras.getInt("age");
            String date = extras.getString("date");
            String time = extras.getString("time");
            String seatType = extras.getString("seatType");
            boolean includeMeal = extras.getBoolean("includeMeal");
            boolean includeInsurance = extras.getBoolean("includeInsurance");

            // Set text views
            textViewTicketName.setText("Name: " + name);
            textViewTicketAge.setText("Age: " + age);
            textViewTicketDate.setText("Date: " + date);
            textViewTicketTime.setText("Time: " + time);
            textViewTicketSeatType.setText("Seat Type: " + seatType);
            textViewTicketMeal.setText("Meal Included: " + (includeMeal ? "Yes" : "No"));
            textViewTicketInsurance.setText("Insurance: " + (includeInsurance ? "Yes" : "No"));
        }

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
