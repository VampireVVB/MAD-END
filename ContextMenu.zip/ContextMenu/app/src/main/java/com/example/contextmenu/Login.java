package com.example.contextmenu;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    EditText email, password;
    Button loginBtn, signupRedirectBtn;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        signupRedirectBtn = findViewById(R.id.signupRedirectBtn);
        db = new DBHelper(this);

        loginBtn.setOnClickListener(v -> {
            String userEmail = email.getText().toString();
            String userPass = password.getText().toString();

            if (userEmail.isEmpty() || userPass.isEmpty()) {
                Toast.makeText(Login.this, "Fill all fields!", Toast.LENGTH_SHORT).show();
            } else {
                boolean valid = db.checkUser(userEmail, userPass);
                if (valid) {
                    startActivity(new Intent(Login.this,MainScreen.class));
                    Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    // Navigate to main screen or home
                } else {
                    Toast.makeText(Login.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signupRedirectBtn.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, SignUpActivity.class));
        });

    }
}