package com.example.contextmenu;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        EditText name, email, password;
        Button signupBtn, loginRedirectBtn;
        DBHelper db;

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);

        password = findViewById(R.id.password);
        signupBtn = findViewById(R.id.signupBtn);
        loginRedirectBtn = findViewById(R.id.loginRedirectBtn);
        db = new DBHelper(this);

        signupBtn.setOnClickListener(v -> {
            String userName = name.getText().toString();
            String userEmail = email.getText().toString();
            String userPass = password.getText().toString();

            if (userName.isEmpty() || userEmail.isEmpty() || userPass.isEmpty()) {
                Toast.makeText(SignUpActivity.this, "Fill all fields!", Toast.LENGTH_SHORT).show();
            } else {
                boolean insert = db.insertUser(userName, userEmail, userPass);
                if (insert) {
                    Toast.makeText(SignUpActivity.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignUpActivity.this, Login.class));
                } else {
                    Toast.makeText(SignUpActivity.this, "Signup Failed! Email already exists.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginRedirectBtn.setOnClickListener(v -> {
            startActivity(new Intent(SignUpActivity.this, Login.class));
        });
    }
}