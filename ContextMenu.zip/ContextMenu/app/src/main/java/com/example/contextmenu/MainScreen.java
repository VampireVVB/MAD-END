package com.example.contextmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.CheckBox;

public class MainScreen extends AppCompatActivity {

    TextView tvLongPressMe;
    CheckBox cbVeg, cbNonVeg, cbExtraLuggage;
    Button btnCheck;
    TextView tvResult;

    RadioGroup radioGroupPayment;
    Button btnSelect;
    TextView tvSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        tvLongPressMe = findViewById(R.id.tvLongPressMe1);
        registerForContextMenu(tvLongPressMe);  // Important: register view for context menu
        cbVeg = findViewById(R.id.cbVeg1);
        cbNonVeg = findViewById(R.id.cbNonVeg1);
        cbExtraLuggage = findViewById(R.id.cbExtraLuggage1);
        btnCheck = findViewById(R.id.btnCheck1);
        tvResult = findViewById(R.id.tvResult1);

        radioGroupPayment=findViewById(R.id.radioGroupPayment1);
        btnSelect=findViewById(R.id.btnSelect1);
        tvSelected=findViewById(R.id.tvSelected1);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder result = new StringBuilder("You selected:\n");

                if (cbVeg.isChecked()) {
                    result.append("• Veg Meal\n");
                }
                if (cbNonVeg.isChecked()) {
                    result.append("• Non-Veg Meal\n");
                }
                if (cbExtraLuggage.isChecked()) {
                    result.append("• Extra Luggage\n");
                }

                if (!cbVeg.isChecked() && !cbNonVeg.isChecked() && !cbExtraLuggage.isChecked()) {
                    result = new StringBuilder("No options selected.");
                }

                tvResult.setText(result.toString());
            }
        });

        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId= radioGroupPayment.getCheckedRadioButtonId();

                if(selectedId!=-1){
                    RadioButton selectedRadioButton= findViewById(selectedId);
                    String paymentMode = selectedRadioButton.getText().toString();
                    tvSelected.setText("Selected Payment Mode: " + paymentMode);
                }
                else {
                    tvSelected.setText("Please select a payment mode.");}
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
        menu.setHeaderTitle("Choose Action");
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.item_edit) {
            Toast.makeText(this, "Edit Booking Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.item_delete) {
            Toast.makeText(this, "Delete Booking Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.item_share) {
            Toast.makeText(this, "Share Ticket Selected", Toast.LENGTH_SHORT).show();
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }
}